@tool @icon("uid://cjwy8gfcombo8")
class_name HitboxComponent2D extends Area2D
## A unified component that can act as either a hitbox or hurtbox

## Emitted when this hitbox successfully hits a hurtbox
signal hit_hurtbox(hurtbox: HitboxComponent2D)
## Emitted when this hurtbox is hit by a hitbox
signal hit_by_hitbox(hitbox: HitboxComponent2D, damage_amount: float)

enum Type {
	HURTBOX, ## Receives damage
	HITBOX,  ## Deals damage
}

## Type of this component
@export var type: Type = Type.HURTBOX:
	set(value):
		type = value
		_setup_collision_layers()
		notify_property_list_changed()

## Amount of damage this hitbox deals (only used when type = HITBOX)
@export var damage: float = 1.0

## Collision layer to use for filtering interactions
@export_flags_2d_physics var hit_layer: int = 0:
	set(v):
		hit_layer = v
		_setup_collision_layers()

## If true, collisions are temporarily disabled
@export var disable_collisions: bool = false

## Prevents the same hitbox from dealing damage multiple times in one frame
var _hits_processed_this_frame: Dictionary = {}


func _validate_property(property: Dictionary) -> void:
	if property.name == "damage" and type != Type.HITBOX:
		property.usage = PROPERTY_USAGE_NO_EDITOR


func _ready() -> void:
	area_entered.connect(_on_area_entered)
	_setup_collision_layers()
	set_process(false)


func _setup_collision_layers() -> void:
	collision_layer = 0
	collision_mask = 0
	monitorable = false
	monitoring = false

	match type:
		Type.HITBOX:
			collision_mask = hit_layer
			monitoring = true

		Type.HURTBOX:
			collision_layer = hit_layer
			monitorable = true


func _process(_delta: float) -> void:
	_hits_processed_this_frame.clear()
	set_process(false)


func _on_area_entered(other_area: Area2D) -> void:
	if disable_collisions or other_area is not HitboxComponent2D:
		return

	var hurtbox := other_area as HitboxComponent2D
	if hurtbox.type != Type.HURTBOX:
		return

	_handle_hit.call_deferred(hurtbox)


func _handle_hit(hurtbox: HitboxComponent2D) -> void:
	if _hits_processed_this_frame.has(hurtbox.get_instance_id()):
		return
	_hits_processed_this_frame[hurtbox.get_instance_id()] = true
	set_process(true)

	hit_hurtbox.emit(hurtbox)
	hurtbox._notify_hit_by(self, damage)


func _notify_hit_by(hitbox: HitboxComponent2D, damage_amount: float) -> void:
	hit_by_hitbox.emit(hitbox, damage_amount)


## Temporarily disable this component from processing collisions
func disable() -> void:
	disable_collisions = true


## Re-enable collision processing
func enable() -> void:
	disable_collisions = false
